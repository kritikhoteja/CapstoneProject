// Used in register.jsp, nominate_units.jsp, upload_assessments.jsp, check_assessments.jsp and allocate_stakeholders.jsp
 
function showProgress() {
	document.getElementById('progress').style.display = 'inline-block';
}